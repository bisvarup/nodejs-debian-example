#!/bin/bash

node files/index.js